#include <iostream>
#include "../headers/Processor.hpp"

int main(void)
{
	Processor mainP;
	mainP.startShell();
	return 0;
}
